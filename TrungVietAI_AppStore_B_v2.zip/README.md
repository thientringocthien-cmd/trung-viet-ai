# Trung Viet AI — Bản B v2

Bản nâng cấp:
- Tải video YouTube.
- Nhận dạng tiếng Trung bằng Faster-Whisper.
- Dịch từng đoạn sang tiếng Việt.
- Tạo TTS tiếng Việt cho từng đoạn.
- Đặt từng đoạn TTS vào đúng timestamp gốc bằng FFmpeg.
- Ghép video + audio Việt và xuất MP4.
- iPhone app theo dõi tiến trình và nhận link video.

## Server
Cần Python 3.10+ và FFmpeg.

pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000

Đưa server lên HTTPS, sau đó sửa:
server = "https://YOUR-SERVER.example.com"
trong ContentView.swift.

## Xcode
Tạo project iOS App SwiftUI tên TrungVietAI, thay ContentView.swift và TrungVietAIApp.swift bằng file trong thư mục iOS.
Chọn Signing Team + Bundle Identifier của bạn rồi Archive/Distribute lên App Store Connect.

## Lưu ý
- TTS tiếng Việt có thể dài hơn câu gốc; bản production nên thêm time-stretch/ducking và lựa chọn giữ/giảm âm thanh gốc.
- Xử lý video dài cần hàng đợi/background worker và storage thật (S3/R2/etc.).
- Chỉ xử lý nội dung mà bạn có quyền truy cập/sử dụng và tuân thủ điều khoản của YouTube.
