import os, uuid, subprocess, threading, json, re
from pathlib import Path
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from deep_translator import GoogleTranslator
from faster_whisper import WhisperModel
from gtts import gTTS

BASE=Path("jobs"); BASE.mkdir(exist_ok=True)
app=FastAPI(title="Trung Viet AI")
app.mount("/files", StaticFiles(directory=BASE), name="files")
jobs={}
MODEL=os.getenv("WHISPER_SIZE","small")
whisper=None

class CreateJob(BaseModel):
    youtube_url:str

def run(cmd):
    return subprocess.run(cmd,check=True,capture_output=True,text=True)

def duration(path):
    r=run(["ffprobe","-v","error","-show_entries","format=duration","-of","default=nw=1:nk=1",str(path)])
    return float(r.stdout.strip())

def worker(job,url):
    d=BASE/job
    try:
        jobs[job]={"status":"processing","message":"Đang tải video…"}
        run(["yt-dlp","-f","bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]","-o",str(d/"source.%(ext)s"),url])
        video=next(d.glob("source.*"))
        # Extract audio for ASR.
        audio=d/"source.wav"
        run(["ffmpeg","-y","-i",str(video),"-vn","-ac","1","-ar","16000",str(audio)])

        global whisper
        if whisper is None:
            jobs[job]["message"]="Đang khởi tạo nhận dạng tiếng Trung…"
            whisper=WhisperModel(MODEL,device="cpu",compute_type="int8")

        jobs[job]["message"]="Đang nhận dạng và dịch tiếng Trung…"
        segments,_=whisper.transcribe(str(audio),language="zh",vad_filter=True)
        rows=[]
        translator=GoogleTranslator(source="zh-CN",target="vi")
        for s in segments:
            zh=s.text.strip()
            if not zh: continue
            vi=translator.translate(zh)
            rows.append({"start":float(s.start),"end":float(s.end),"zh":zh,"vi":vi})

        if not rows:
            raise RuntimeError("Không nhận diện được lời nói tiếng Trung.")

        (d/"transcript.json").write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding="utf8")
        jobs[job]["message"]=f"Đã dịch {len(rows)} đoạn. Đang tạo giọng Việt…"

        # Create one TTS file per segment.
        for i,row in enumerate(rows):
            p=d/f"tts_{i:05d}.mp3"
            gTTS(row["vi"],lang="vi",slow=False).save(str(p))
            row["tts"]=str(p)

        # Place each TTS clip at its original start timestamp.
        total=duration(video)
        inputs=[]
        filters=[]
        for i,row in enumerate(rows):
            p=row["tts"]
            inputs += ["-i",p]
            filters.append(f"[{i+1}:a]adelay={max(0,int(row['start']*1000))}|{max(0,int(row['start']*1000))},apad[a{i}]")
        mix_inputs="".join(f"[a{i}]" for i in range(len(rows)))
        filters.append(f"{mix_inputs}amix=inputs={len(rows)}:duration=longest:dropout_transition=0[va]")
        filter_complex=";".join(filters)
        vi_audio=d/"voice_vi.wav"
        run(["ffmpeg","-y",*inputs,"-filter_complex",filter_complex,"-map","[va]","-t",str(total),str(vi_audio)])

        jobs[job]["message"]="Đang ghép giọng Việt vào video…"
        out=d/"trung-viet.mp4"
        run(["ffmpeg","-y","-i",str(video),"-i",str(vi_audio),
             "-map","0:v:0","-map","1:a:0","-c:v","copy","-c:a","aac","-b:a","128k",
             "-shortest",str(out)])
        jobs[job]={"status":"completed","message":"Hoàn tất video có giọng Việt đồng bộ.",
                   "download_url":f"/files/{job}/trung-viet.mp4"}
    except Exception as e:
        jobs[job]={"status":"error","message":str(e)[:1500]}

@app.post("/jobs")
def create(req:CreateJob):
    if not re.match(r"^https?://(www\.)?(youtube\.com|youtu\.be)/",req.youtube_url):
        return {"status":"error","message":"Link YouTube không hợp lệ."}
    job=uuid.uuid4().hex
    (BASE/job).mkdir()
    jobs[job]={"status":"queued","message":"Đã nhận yêu cầu."}
    threading.Thread(target=worker,args=(job,req.youtube_url),daemon=True).start()
    return {"job_id":job,"status":"queued","message":"Đã nhận yêu cầu.","download_url":None}

@app.get("/jobs/{job}")
def status(job:str):
    return jobs.get(job,{"status":"error","message":"Không tìm thấy tác vụ."})
