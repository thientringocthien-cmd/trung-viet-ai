import SwiftUI

struct Job: Codable {
    let job_id: String?
    let status: String
    let message: String?
    let download_url: String?
}

struct ContentView: View {
    @State private var url=""
    @State private var status="Dán link YouTube tiếng Trung."
    @State private var working=false
    @State private var resultURL: URL?
    private let server="https://YOUR-SERVER.example.com"

    var body: some View {
        NavigationStack {
            Form {
                Section("Video YouTube") {
                    TextField("https://youtube.com/...",text:$url)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.URL)
                    Button(working ? "ĐANG XỬ LÝ…" : "DỊCH + LỒNG TIẾNG VIỆT") {
                        Task { await start() }
                    }.disabled(working || url.isEmpty)
                }
                Section("Tiến trình") {
                    Text(status)
                    if let u=resultURL { Link("▶ Mở / tải video MP4",destination:u) }
                }
                Section("Tính năng") {
                    Label("Nhận dạng tiếng Trung bằng AI",systemImage:"waveform")
                    Label("Dịch Trung → Việt",systemImage:"character.book.closed")
                    Label("Đồng bộ từng câu theo thời gian video",systemImage:"clock")
                    Label("Giọng đọc tiếng Việt",systemImage:"speaker.wave.2")
                    Label("Xuất MP4",systemImage:"film")
                }
            }.navigationTitle("Trung → Việt AI")
        }
    }

    @MainActor
    func start() async {
        guard let endpoint=URL(string:server+"/jobs") else { status="Chưa cấu hình server."; return }
        working=true; resultURL=nil; status="Đang gửi video…"
        defer { working=false }
        var r=URLRequest(url:endpoint); r.httpMethod="POST"
        r.setValue("application/json",forHTTPHeaderField:"Content-Type")
        r.httpBody=try? JSONSerialization.data(withJSONObject:["youtube_url":url])
        do {
            let (data,_)=try await URLSession.shared.data(for:r)
            let job=try JSONDecoder().decode(Job.self,from:data)
            guard let id=job.job_id else { status=job.message ?? "Lỗi"; return }
            await poll(id)
        } catch { status="Lỗi kết nối: \(error.localizedDescription)" }
    }

    @MainActor
    func poll(_ id:String) async {
        for _ in 0..<900 {
            try? await Task.sleep(for:.seconds(2))
            guard let u=URL(string:server+"/jobs/"+id) else { return }
            do {
                let (data,_)=try await URLSession.shared.data(from:u)
                let j=try JSONDecoder().decode(Job.self,from:data)
                status=j.message ?? j.status
                if j.status=="completed",let path=j.download_url,let u=URL(string:server+path) {
                    resultURL=u; return
                }
                if j.status=="error" { return }
            } catch {}
        }
        status="Tác vụ quá lâu. Hãy kiểm tra server."
    }
}
