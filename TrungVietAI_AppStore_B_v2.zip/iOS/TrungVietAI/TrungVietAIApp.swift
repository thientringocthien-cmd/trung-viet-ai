import SwiftUI

@main
struct TrungVietAIApp: App {
    var body: some Scene { WindowGroup { ContentView() } }
}
